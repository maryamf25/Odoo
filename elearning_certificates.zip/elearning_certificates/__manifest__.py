# -*- coding: utf-8 -*-
{
    'name': "Certificates for eLearning",
    'summary': "Adds certificate functionality to eLearning courses",
    'description': """
This module extends the eLearning module to allow admins to set certificates for courses. Students will be able to download their certificates upon course completion.
    """,
    'author': "Ustadam",
    'website': "https://ustadam.org/",
    'category': 'eLearning',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'website_slides', 'portal'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/inherited_slide_channel_view_kanban.xml',
        'views/certificate_pdf_report.xml',
        'views/course_certificate.xml',
        'views/certificate_view.xml',
        'views/action.xml',
        'views/menu_item.xml',
    ],
}
