import sys
import subprocess
from odoo import http
from odoo.http import request
import base64
from io import BytesIO
import logging
import os


# Function to install a package if not installed
def install_package(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])


try:
    from pdf2image import convert_from_bytes
except ImportError:
    install_package("pdf2image")

_logger = logging.getLogger(__name__)

class MyModuleController(http.Controller):

    @http.route('/certificates', type='http', auth='user', website=True)
    def certificates(self, **kwargs):

        user = request.env.user.sudo()
        partner = user.partner_id

        enrolled_courses = request.env['slide.channel.partner'].sudo().search([
            ('partner_id', '=', partner.id),
            ('member_status', 'in', ['Finshed', 'completed'])
        ]).mapped('channel_id')

        _logger.info('Enrolled Courses: %s', enrolled_courses.ids)

        certificates = request.env['certificate'].sudo().search([
            ('course_id', 'in', enrolled_courses.ids)
        ])

        for certificate in certificates:
            _logger.info('Certificate ID: %s, Course ID: %s', certificate.id, certificate.course_id.id)
        return request.render('elearning_certificates.portal_certificates', {
            'user': user,
            'certificates': certificates
        })

    @http.route('/certificate/<int:certificate_id>-<string:token>/<int:user_id>', type='http', auth='public', website=True)
    def certificate_sharing(self, certificate_id, token, user_id, **kwargs):
        certificate = request.env['certificate'].sudo().search([('id', '=', certificate_id)], limit=1)
        if not certificate:
            return request.not_found()
        user = request.env['res.users'].sudo().search([('id', '=', user_id)], limit=1)

        report_action = request.env.ref('elearning_certificates.school_student_profile_report_temp')
        if not report_action:
            return request.not_found()
        print('Userrrrrrrr:', user_id)
        pdf_content, content_type = request.env['ir.actions.report'].sudo()._render_qweb_pdf(
            report_action.id, [certificate.id], {'user_id': user.id})

        response = request.make_response(
            pdf_content,
            headers=[
                ('Content-Type', 'application/pdf'),
                ('Content-Disposition', 'inline; filename=certificate.pdf')
            ]
        )
        return response

    @http.route('/certificate/preview/<int:certificate_id>', type='http', auth='public', website=True)
    def certificate_preview(self, certificate_id, **kwargs):
        certificate = request.env['certificate'].sudo().search([('id', '=', certificate_id)], limit=1)
        current_user = request.env.user.sudo()

        if not certificate:
            return request.not_found()

        # Ensure user_id is set correctly
        user_id = current_user.id

        report_action = request.env.ref('elearning_certificates.school_student_profile_report_temp')
        if not report_action:
            return request.not_found()

        pdf_content, _ = request.env['ir.actions.report'].sudo()._render_qweb_pdf(
            report_action.id, [certificate.id], {'user_id': user_id}
        )

        poppler_relative_path = '../poppler-24.07.0/Library/bin'
        poppler_path = os.path.abspath(os.path.join(os.path.dirname(__file__), poppler_relative_path))
        images = convert_from_bytes(
            pdf_content,
            poppler_path=poppler_path
        )

        if not images:
            return request.not_found()

        img_buffer = BytesIO()
        images[0].save(img_buffer, format='PNG')
        img_buffer.seek(0)
        image_data = img_buffer.read()
        image_base64 = base64.b64encode(image_data).decode('utf-8')

        return request.make_response(
            base64.b64decode(image_base64),
            headers=[
                ('Content-Type', 'image/png'),
                ('Content-Disposition', 'inline; filename=certificate_preview.png')
            ]
        )
