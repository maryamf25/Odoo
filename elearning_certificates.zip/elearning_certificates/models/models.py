from odoo import models, fields
import logging
from odoo.exceptions import ValidationError
import uuid
from odoo.http import request

_logger = logging.getLogger(__name__)

class ChannelUsersRelation(models.Model):
    _inherit = 'slide.channel.partner'

    completion_date = fields.Date(string='Course Completion Date', required=True, default=fields.Date.today)

class SlideChannel(models.Model):
    _inherit = 'slide.channel'
    
    certificate_ids = fields.One2many('certificate', 'course_id', string='Certificates')

class Certificate(models.Model):
    _name = 'certificate'
    _description = 'Certificate'

    BackgroundImg = fields.Image(string='Background Image')
    Logo = fields.Image(string='Logo', help="Background should be transparent")
    Signature = fields.Image(string='Signature', help="Background should be transparent")
    course_id = fields.Many2one('slide.channel', string='Course', required=True)  # Inverse field 'certificate_ids'
    user_certificate_ids = fields.One2many('slide.certificate.partner', 'certificate_id', string='User Certificate Id')

    def _check_unique_course_certificate(self):
        for record in self:
            existing_certificate = self.search([('course_id', '=', record.course_id.id), ('id', '!=', record.id)])
            if existing_certificate:
                raise ValidationError("A certificate for this course already exists.")

    def create_report(self):
        report = self.env.ref('elearning_certificates.school_student_profile_report_temp')
        return report.report_action(self)
    
class CertificateUsersRelation(models.Model):
    _name = 'slide.certificate.partner'
    _description = 'User Certificates'

    user_id = fields.Many2one('res.users', string='User', required=True)
    certificate_id = fields.Many2one('certificate', string='Certificate', required=True)
    public_url = fields.Char(string='Public URL', readonly=True)
    
    def generate_public_url(self):
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        unique_token = f"{self.certificate_id.id}-{uuid.uuid4()}"
        user_id = self.env.user.id
        return f"{base_url}/certificate/{unique_token}/{user_id}"

    def get_public_url(self, certificate_id):
        user = request.env.user.sudo()
        
        certificate = request.env['certificate'].browse(int(certificate_id))
        if not certificate:
            _logger.error(f"Certificate not found for ID: {certificate_id}")
            return {'error': 'Certificate not found'}

        certificate.create_report()

        user_certificate = request.env['slide.certificate.partner'].search([
            ('user_id', '=', user.id),
            ('certificate_id', '=', certificate.id)
        ], limit=1)

        if not user_certificate:
            user_certificate = request.env['slide.certificate.partner'].create({
                'user_id': user.id,
                'certificate_id': certificate.id,
            })
            user_certificate.public_url = user_certificate.generate_public_url()

        public_url = user_certificate.public_url

        if not public_url:
            _logger.error(f"Public URL not generated for user_certificate ID: {user_certificate.id}")

        return public_url

    
